<button type="button"
    class="inline-flex justify-center items-center space-x-2 rounded focus:outline-none px-3 py-2 leading-6 bg-blue-100 hover:bg-blue-200 focus:ring focus:ring-blue-100 focus:ring-opacity-50 active:bg-blue-100 active:border-blue-100">
    <p class="font-semibold text-blue-700">{{ $slot }}</p>
</button>

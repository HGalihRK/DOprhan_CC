<?php

namespace App\Http\Controllers;

use App\Http\Requests\Storetutor_day_time_rangeRequest;
use App\Http\Requests\Updatetutor_day_time_rangeRequest;
use App\Models\tutor_day_time_range;

class TutorDayTimeRangeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\Storetutor_day_time_rangeRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Storetutor_day_time_rangeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\tutor_day_time_range  $tutor_day_time_range
     * @return \Illuminate\Http\Response
     */
    public function show(tutor_day_time_range $tutor_day_time_range)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\tutor_day_time_range  $tutor_day_time_range
     * @return \Illuminate\Http\Response
     */
    public function edit(tutor_day_time_range $tutor_day_time_range)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\Updatetutor_day_time_rangeRequest  $request
     * @param  \App\Models\tutor_day_time_range  $tutor_day_time_range
     * @return \Illuminate\Http\Response
     */
    public function update(Updatetutor_day_time_rangeRequest $request, tutor_day_time_range $tutor_day_time_range)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\tutor_day_time_range  $tutor_day_time_range
     * @return \Illuminate\Http\Response
     */
    public function destroy(tutor_day_time_range $tutor_day_time_range)
    {
        //
    }
}
